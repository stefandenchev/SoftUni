﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Common
{
    public static class ExceptionMessages
    {
        public const string InvalidType = "Invalid type!";
    }
}
