﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WildFarm.Models.Animals.Contracts
{
    public interface ISoundProducible
    {
        string ProduceSound();
    }
}