﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Raiding.Common
{
    public static class ExceptionMessages
    {
        public const string InvalidClassMsg = "Invalid hero!";
    }
}
