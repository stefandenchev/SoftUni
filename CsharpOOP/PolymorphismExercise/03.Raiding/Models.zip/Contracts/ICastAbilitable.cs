﻿namespace _03.Raiding.Contracts
{
   public  interface ICastAbilitable
    {
        public string CastAbility();
    }
}
