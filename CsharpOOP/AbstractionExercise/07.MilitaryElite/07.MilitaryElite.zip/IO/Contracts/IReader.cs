﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.MilitaryElite.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}