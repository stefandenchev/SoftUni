﻿namespace Git.ViewModels.Commits
{
    public class CreateCommitInputModel
    {
        public string Id { get; set; }
        public string Description { get; set; }
    }
}
