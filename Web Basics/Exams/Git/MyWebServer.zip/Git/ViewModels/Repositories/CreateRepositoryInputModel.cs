﻿namespace Git.ViewModels.Repositories
{
    public class CreateRepositoryInputModel
    {
        public string Name { get; set; }

        public string Type { get; set; }
    }
}
