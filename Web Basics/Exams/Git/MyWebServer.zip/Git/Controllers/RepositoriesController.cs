﻿using Git.Data;
using Git.Data.Models;
using Git.Services;
using Git.ViewModels.Repositories;
using MyWebServer.Controllers;
using MyWebServer.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Git.Controllers
{
    public class RepositoriesController : Controller
    {
        private readonly ApplicationDbContext db;
        private readonly IValidator validator;

        public RepositoriesController(
            ApplicationDbContext db,
            IValidator validator)
        {
            this.db = db;
            this.validator = validator;
        }

        [Authorize]
        public HttpResponse Create()
        {
            return this.View();
        }

        [Authorize]
        [HttpPost]
        public HttpResponse Create(CreateRepositoryInputModel model)
        {
            var modelErrors = this.validator.ValidateRepository(model);

            if (modelErrors.Any())
            {
                return Error(modelErrors);
            }

            var repository = new Repository
            {
                Name = model.Name,
                CreatedOn = DateTime.UtcNow,
                IsPublic = model.Type == "Public",
                OwnerId = this.User.Id
            };

            this.db.Repositories.Add(repository);

            this.db.SaveChanges();

            return Redirect("/Repositories/All");
        }


        [Authorize]
        public HttpResponse All()
        {
            var repsQuery = this.db.Repositories.AsQueryable();

            var repositories = repsQuery
                .Select(x => new RepositoryViewModel
                {
                    Id = x.Id,
                    Name = x.Name,
                    Owner = x.Owner.Username,
                    CreatedOn = x.CreatedOn,
                    CommitsCount = x.Commits.Count(),
                })
                .ToList();

            return View(repositories);
        }
    }
}
