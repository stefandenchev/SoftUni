﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DTO
{
    public class CategoryInputModel
    {
        public string Name { get; set; }
    }
}
