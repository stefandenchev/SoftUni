﻿namespace SoftJail.DataProcessor.ExportDto
{
    public class ExOfficerDto
    {
        public string OfficerName { get; set; }
        public string Department { get; set; }
    }
}